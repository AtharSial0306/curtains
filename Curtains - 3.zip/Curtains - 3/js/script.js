const faqBox = document.querySelectorAll(".faqs-box");
const plusBtn = document.querySelectorAll(".faq-icon-box");
const question = document.querySelectorAll(".question");

console.log(plusBtn);
for (let i = 0; i < faqBox.length; i++) {
  //   console.log(plusBtn[i]);
  //   console.log(faqBox[i]);
  plusBtn[i].addEventListener("click", () => {
    closeAllFAQsExcept(i);
    faqBox[i].classList.toggle("open");
  });
  question[i].addEventListener("click", () => {
    closeAllFAQsExcept(i);
    faqBox[i].classList.toggle("open");
  });
}

function closeAllFAQsExcept(currentIndex) {
  for (let j = 0; j < faqBox.length; j++) {
    if (j !== currentIndex) {
      faqBox[j].classList.remove("open");
    }
  }
}

const headerMenu = document.querySelector(".header-menu");
const burger = document.querySelector("#burger");
const close = document.querySelector("#close");

burger.addEventListener("click", () => {
  headerMenu.classList.toggle("nav-open");
});
close.addEventListener("click", () => {
  headerMenu.classList.remove("nav-open");
});

// TABS
function openTab(evt, tabName) {
  let tabContent = document.getElementsByClassName("tab-content");
  for (let i = 0; i < tabContent.length; i++) {
    tabContent[i].style.display = "none";
  }
  let tabLinks = document.getElementsByClassName("tab-link");
  for (let i = 0; i < tabLinks.length; i++) {
    tabLinks[i].className = tabLinks[i].className.replace(" active", "");
  }
  document.getElementById(tabName).style.display = "block";
  evt.currentTarget.className += " active";
}
document.getElementsByClassName("tab-link")[0].click();
